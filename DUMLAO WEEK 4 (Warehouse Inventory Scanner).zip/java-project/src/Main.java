import java.util.Scanner;

public class Main {

    static Scanner input = new Scanner(System.in);
    
    static int[][] warehouse = {
        {10, 5, -1},
        {2, 15, 8},
        {1, 12, 6}
    };

    static final int LOW_STOCK = 3;

    public static void main(String[] args) {

        int choice;

        do {
            System.out.println("\n=== WAREHOUSE INVENTORY SCANNER ===");
            System.out.println("1. Display Inventory");
            System.out.println("2. Total Inventory");
            System.out.println("3. Find Critically Low Shelf");
            System.out.println("4. Restock Shelf");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            while (!input.hasNextInt()) {
                System.out.print("Invalid input. Enter a number: ");
                input.next();
            }

            choice = input.nextInt();

            switch (choice) {
                case 1:
                    displayInventory();
                    break;

                case 2:
                    totalInventory();
                    break;

                case 3:
                    findLowStock();
                    break;

                case 4:
                    restockShelf();
                    break;

                case 5:
                    System.out.println("Exiting inventory system...");
                    break;

                default:
                    System.out.println("Invalid menu choice.");
            }

        } while (choice != 5);
    }

    static void displayInventory() {
        System.out.println("\nWarehouse Inventory:");

        for (int row = 0; row < warehouse.length; row++) {
            for (int col = 0; col < warehouse[row].length; col++) {
                if (warehouse[row][col] == -1) {
                    System.out.print("[DAMAGED] ");
                } else {
                    System.out.print(warehouse[row][col] + " ");
                }
            }
            System.out.println();
        }
    }

    static void totalInventory() {
        int total = 0;

        for (int row = 0; row < warehouse.length; row++) {
            for (int col = 0; col < warehouse[row].length; col++) {

                if (warehouse[row][col] == -1) {
                    continue;
                }

                total += warehouse[row][col];
            }
        }

        System.out.println("Total inventory: " + total + " items");
    }

    static void findLowStock() {
        boolean found = false;

        for (int row = 0; row < warehouse.length; row++) {
            for (int col = 0; col < warehouse[row].length; col++) {

                if (warehouse[row][col] != -1
                        && warehouse[row][col] <= LOW_STOCK) {

                    System.out.println(
                        "Critically low shelf found at Row "
                        + (row + 1) + ", Column " + (col + 1)
                        + " with " + warehouse[row][col] + " items."
                    );

                    found = true;

                    break;
                }
            }

            if (found) {
                break;
            }
        }

        if (!found) {
            System.out.println("No critically low shelves found.");
        }
    }
    
    static void restockShelf() {
        System.out.print("Enter row (1-" + warehouse.length + "): ");
        int row = readInteger();

        System.out.print("Enter column (1-" + warehouse[0].length + "): ");
        int col = readInteger();

        if (row < 1 || row > warehouse.length
                || col < 1 || col > warehouse[0].length) {
            System.out.println("Invalid shelf location.");
            return;
        }

        if (warehouse[row - 1][col - 1] == -1) {
            System.out.println("Cannot restock a damaged shelf.");
            return;
        }

        System.out.print("Enter quantity to add: ");
        int quantity = readInteger();

        while (quantity <= 0) {
            System.out.print(
                "Invalid quantity. Enter a positive number: "
            );
            quantity = readInteger();
        }

        warehouse[row - 1][col - 1] += quantity;

        System.out.println("Restocking successful!");
        System.out.println(
            "Updated stock: " + warehouse[row - 1][col - 1]
        );
    }

    static int readInteger() {
        while (!input.hasNextInt()) {
            System.out.print("Invalid input. Enter a whole number: ");
            input.next();
        }

        return input.nextInt();
    }
}
