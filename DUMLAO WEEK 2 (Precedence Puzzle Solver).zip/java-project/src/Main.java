public class Main {
    public static void main(String[] args) {

        System.out.println("===== Precedence Puzzle Solver =====");

        // Puzzle 1
        int a = 5;
        int b = 3;

        // PREDICTED: true
        // Multiplication happens before addition, then comparison.
        System.out.println("Puzzle 1: " + (a + b * 2 > 10 && a < 6));

        // Puzzle 2
        int x = 4;
        int y = 7;

        // PREDICTED: true
        // Increment happens before multiplication and comparison.
        System.out.println("Puzzle 2: " + (++x * 2 < y + 3 || y == 7));

        // Puzzle 3
        int count = 5;

        // PREDICTED: 5 and then 6
        // Postfix increment uses the old value before increasing count.
        System.out.println("Puzzle 3 result: " + (count++ > 4 && count == 6));
        System.out.println("Count after Puzzle 3: " + count);

    }
}
