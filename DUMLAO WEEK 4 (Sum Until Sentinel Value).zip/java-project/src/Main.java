public class Main {
    public static void main(String[] args) {

        int[] numbers = {10, 5, -3, 8, -1};
        int total = 0;
        int i = 0;

        while (numbers[i] != -1) {
            total += numbers[i];
            i++;
        }

        System.out.println("Numbers: 10, 5, -3, 8, -1");
        System.out.println("Final Total: " + total);
    }
}
