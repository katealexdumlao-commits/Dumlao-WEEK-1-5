public class Main {

    static class Student {
        String name;
        int[] quizzes;
        double average;

        Student(String name, int[] quizzes) {
            this.name = name;
            this.quizzes = quizzes;

            int sum = 0;
            for (int score : quizzes) {
                sum += score;
            }

            average = (double) sum / quizzes.length;
        }
    }

    static int searchRank(Student[] students, String targetName) {
        for (int i = 0; i < students.length; i++) {
            if (students[i].name.equalsIgnoreCase(targetName)) {

                if (i > 0 &&
                    Double.compare(students[i].average,
                                   students[i - 1].average) == 0) {
                    return searchRankForPrevious(students, i - 1);
                }

                return i + 1;
            }
        }

        return -1; 
    }

    static int searchRankForPrevious(Student[] students, int index) {
        while (index > 0 &&
               Double.compare(students[index].average,
                              students[index - 1].average) == 0) {
            index--;
        }

        return index + 1;
    }

    static void sortStudents(Student[] students) {
        for (int i = 0; i < students.length - 1; i++) {
            for (int j = 0; j < students.length - 1 - i; j++) {

                if (students[j].average < students[j + 1].average) {
                    Student temp = students[j];
                    students[j] = students[j + 1];
                    students[j + 1] = temp;
                }
            }
        }
    }

    public static void main(String[] args) {

        String[] names = {
            "Alex", "Jamie", "Taylor", "Morgan", "Casey"
        };

        int[][] rawQuizData = {
            {90, 85, 88, 95},
            {92, 90, 91, 93},
            {85, 88, 90, 87},
            {92, 90, 91, 93},
            {78, 82, 80, 85}
        };

        Student[] students = new Student[names.length];

        for (int i = 0; i < names.length; i++) {
            students[i] = new Student(names[i], rawQuizData[i]);
        }

        sortStudents(students);

        System.out.println("========== CLASS LEADERBOARD ==========");
        System.out.printf("%-8s %-12s %-10s %-10s%n",
                "Rank", "Name", "Average", "Quizzes");
        System.out.println("---------------------------------------");

        int rank = 1;

        for (int i = 0; i < students.length; i++) {
            if (i > 0 &&
                Double.compare(students[i].average,
                               students[i - 1].average) != 0) {
                rank = i + 1;
            }

            System.out.printf("%-8d %-12s %-10.2f %s%n",
                    rank,
                    students[i].name,
                    students[i].average,
                    java.util.Arrays.toString(students[i].quizzes));
        }

        String targetName = "Morgan";
        int studentRank = searchRank(students, targetName);

        System.out.println("\n========== STUDENT SEARCH ==========");

        if (studentRank != -1) {
            System.out.println(targetName + " is ranked #" + studentRank);
        } else {
            System.out.println(targetName + " was not found.");
        }
    }
}
