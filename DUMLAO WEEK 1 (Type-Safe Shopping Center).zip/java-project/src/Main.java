public class Main {
    public static void main(String[] args) {

        // Declare variables with appropriate data types
        int quantity = 3;
        double unitPrice = 49.99;
        String storeName = "Elio Store";

        // Calculate the total cost
        double totalCost = quantity * unitPrice;

        // Print the itemized shopping summary
        System.out.println("===== Shopping Summary =====");
        System.out.println("Store Name: " + storeName);
        System.out.println("Quantity: " + quantity);
        System.out.printf("Unit Price: $%.2f%n", unitPrice);
        System.out.printf("Total Cost: $%.2f%n", totalCost);

        // totalCost should NOT be an int because prices can
        // contain decimal values, and int would lose the cents.
    }
}
