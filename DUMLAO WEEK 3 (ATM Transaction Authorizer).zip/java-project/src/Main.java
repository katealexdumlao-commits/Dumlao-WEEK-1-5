public class Main {
    public static void main(String[] args) {

        String username = "katedumlao";
        String correctUsername = "katedumlao";

        int pin = 1234;
        int correctPin = 1234;

        double balance = 25000.00;
        double withdrawal = 5000.00;

        String tier = "";
        double dailyLimit = 0;
        double feeRate = 0;
        double fee = 0;
        double totalDeduction = 0;

        String denialReason = "";

        if (username.equals(correctUsername)) {
            if (pin >= 1000 && pin <= 9999 && pin == correctPin) {

                if (balance < 10000) {
                    tier = "Bronze";
                    dailyLimit = 2000;
                } else if (balance < 25000) {
                    tier = "Silver";
                    dailyLimit = 5000;
                } else if (balance < 50000) {
                    tier = "Gold";
                    dailyLimit = 10000;
                } else {
                    tier = "Platinum";
                    dailyLimit = 20000;
                }

                System.out.println("Account Tier: " + tier);
                System.out.println("Current Balance: P" + balance);
                System.out.println("Withdrawal Amount: P" + withdrawal);
                System.out.println("Daily Withdrawal Limit: P" + dailyLimit);

                switch (tier) {
                    case "Bronze":
                        feeRate = 0.02;
                        break;
                    case "Silver":
                        feeRate = 0.015;
                        break;
                    case "Gold":
                        feeRate = 0.01;
                        break;
                    case "Platinum":
                        feeRate = 0.005;
                        break;
                    default:
                        denialReason = "Invalid account tier.";
                }

                if (denialReason.isEmpty()) {
                    if (withdrawal > 0) {
                        if (withdrawal <= balance) {
                            if (withdrawal <= dailyLimit) {
                                fee = withdrawal * feeRate;
                                totalDeduction = withdrawal + fee;

                                if (totalDeduction <= balance) {
                                    System.out.println("\nTRANSACTION APPROVED");
                                    System.out.println("Transaction Fee: P" + fee);
                                    System.out.println("Total Deduction: P" + totalDeduction);
                                    System.out.println("Remaining Balance: P"
                                            + (balance - totalDeduction));
                                } else {
                                    denialReason =
                                            "Insufficient balance to cover withdrawal and fee.";
                                }
                            } else {
                                denialReason =
                                        "Withdrawal exceeds the daily limit for your tier.";
                            }
                        } else {
                            denialReason =
                                    "Insufficient balance for the requested withdrawal.";
                        }
                    } else {
                        denialReason =
                                "Withdrawal amount must be greater than zero.";
                    }
                }

                if (!denialReason.isEmpty()) {
                    System.out.println("\nTRANSACTION DENIED");
                    System.out.println("Reason: " + denialReason);
                }

            } else {
                System.out.println("TRANSACTION DENIED");
                System.out.println(
                        "Reason: Invalid PIN or PIN must contain exactly 4 digits.");
            }
        } else {
            System.out.println("TRANSACTION DENIED");
            System.out.println("Reason: Invalid username.");
        }
    }
}
