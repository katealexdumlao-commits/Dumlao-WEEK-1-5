public class Main {
    public static void main(String[] args) {

        // Declare the student's average grade and absences
        double average = 85;
        int absences = 2;

        // Check if the student meets the passing requirements
        // The student passes if:
        // 1. Average is at least 75 AND absences are at most 3
        // OR
        // 2. Average is at least 90, regardless of absences
        boolean passed = (average >= 75 && absences <= 3)
                         || (average >= 90);

        // Print the student's information
        System.out.println("===== Grade Threshold Checker =====");
        System.out.println("Average Grade: " + average);
        System.out.println("Number of Absences: " + absences);

        // Display the result and reasoning
        if (passed) {
            System.out.println("Result: PASS");

            if (average >= 90) {
                System.out.println("Reason: Average is at least 90.");
            } else {
                System.out.println("Reason: Average is at least 75 and absences are not more than 3.");
            }
        } else {
            System.out.println("Result: FAIL");
            System.out.println("Reason: Average is below 90, and the student does not meet both the minimum grade and attendance requirements.");
        }
    }
}

