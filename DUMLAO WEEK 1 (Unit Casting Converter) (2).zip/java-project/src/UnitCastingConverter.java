public class UnitCastingConverter {
    public static void main(String[] args) {

        // Declare a double value representing centimeters
        double centimeters = 275.5;

        // Explicit casting: convert the result to a whole number
        int wholeMeters = (int) (centimeters / 100);

        // Calculate the remaining centimeters
        double remainingCm = centimeters - (wholeMeters * 100);

        // Print the converted measurements
        System.out.println("===== Unit Casting Converter =====");
        System.out.println("Centimeters: " + centimeters);
        System.out.println("Whole Meters: " + wholeMeters);
        System.out.println("Remaining Centimeters: " + remainingCm);

        // Implicit widening: int to double
        // No cast is needed because Java automatically converts
        // an int to a double, preserving its numeric value.
        int number = 25;
        double widenedNumber = number;

        System.out.println("\n===== Implicit Widening =====");
        System.out.println("Integer Value: " + number);
        System.out.println("Widened Double Value: " + widenedNumber);

        // Explicit narrowing: double to int
        // The fractional part (.75) is lost when 19.75 becomes 19.
        double decimalValue = 19.75;
        int narrowedValue = (int) decimalValue;

        System.out.println("\n===== Explicit Narrowing =====");
        System.out.println("Original Double: " + decimalValue);
        System.out.println("Narrowed Integer: " + narrowedValue);
    }
}
