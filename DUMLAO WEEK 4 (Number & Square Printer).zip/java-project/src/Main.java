public class Main {
    public static void main(String[] args) {

        for (int number = 1; number <= 20; number++) {
            int square = number * number;

            System.out.println("Number: " + number + " | Square: " + square);
        }
    }
}
