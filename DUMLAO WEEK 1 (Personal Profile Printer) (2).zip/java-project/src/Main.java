public class Main {
    public static void main(String[] args) {

        // Declare primitive type variables
        int age = 20;              // Stores the age as a whole number
        double height = 152.4;      // Stores the height with decimals
        char initial = 'K';        // Stores a single character
        boolean isStudent = true;  // Stores true or false

        // Declare a reference type variable
        String fullName = "Kate Alex L. Dumlao"; // Stores the full name

        // Print the personal profile heading
        System.out.println("Personal Profile");

        // Display the values of each variable
        System.out.println("Full Name: " + fullName);
        System.out.println("Age: " + age);
        System.out.println("Height: " + height + " meters");
        System.out.println("Initial: " + initial);
        System.out.println("Student Status: " + isStudent);
    }
}
