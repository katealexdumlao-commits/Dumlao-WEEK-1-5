public class OverflowandReferenceInvestigator {
    public static void main(String[] args) {

        // 1. Demonstrate byte overflow
        System.out.println("===== Byte Overflow =====");

        byte number = 127;
        System.out.println("Before increment: " + number);

        number++;

        // A byte can store values from -128 to 127.
        // Incrementing 127 wraps around to -128.
        System.out.println("After increment: " + number);


        // 2. Demonstrate String comparisons
        System.out.println("\n===== String Comparisons =====");

        String text1 = new String("Hello");
        String text2 = new String("Hello");
        String text3 = "Hello";

        // == is false because text1 and text2 refer to different objects.
        System.out.println("text1 == text2: " + (text1 == text2));

        // .equals() is true because both Strings contain the same text.
        System.out.println("text1.equals(text2): " + text1.equals(text2));

        // == is false because text1 refers to a new object,
        // while text3 refers to the string literal in the String pool.
        System.out.println("text1 == text3: " + (text1 == text3));

        // .equals() is true because both contain "Hello".
        System.out.println("text1.equals(text3): " + text1.equals(text3));

        // == is false because text2 is a separate object from text3.
        System.out.println("text2 == text3: " + (text2 == text3));

        // .equals() is true because both contain the same text.
        System.out.println("text2.equals(text3): " + text2.equals(text3));


        // 3. Demonstrate shared array references
        System.out.println("\n===== Shared Array Reference =====");

        int[] firstArray = {10, 20, 30};
        int[] secondArray = firstArray;

        System.out.println("Before modification: " + secondArray[0]);

        // Both variables refer to the same array object.
        // Changes through firstArray are visible through secondArray.
        firstArray[0] = 99;

        System.out.println("After modification: " + secondArray[0]);
    }
}
