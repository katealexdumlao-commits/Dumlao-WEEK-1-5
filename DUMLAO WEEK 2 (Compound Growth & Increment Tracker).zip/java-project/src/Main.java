public class Main {
    public static void main(String[] args) {

        // 1. Track balance growth using compound assignment operators
        double balance = 1000.00;

        System.out.println("===== Compound Growth Tracker =====");
        System.out.println("Initial Balance: " + balance);

        // Step 1: Add 200 to the balance using +=
        balance += 200;
        System.out.println("After Step 1 (+200): " + balance);

        // Step 2: Increase the balance by 10% using *=
        balance *= 1.10;
        System.out.println("After Step 2 (+10%): " + balance);

        // Step 3: Add another 150 using +=
        balance += 150;
        System.out.println("After Step 3 (+150): " + balance);


        // 2. Demonstrate postfix increment
        System.out.println("\n===== Postfix Increment =====");

        int count = 5;

        // count++ uses the current value first, then increments it.
        System.out.println("count++ result: " + count++);
        System.out.println("Count after count++: " + count);


        // 3. Demonstrate prefix increment
        System.out.println("\n===== Prefix Increment =====");

        count = 5;

        // ++count increments the value first, then uses the new value.
        // Therefore, ++count prints 6, while count++ prints 5.
        System.out.println("++count result: " + (++count));
        System.out.println("Count after ++count: " + count);
    }
}
