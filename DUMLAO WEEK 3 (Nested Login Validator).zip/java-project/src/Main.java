public class Main {
    public static void main(String[] args) {

        // Declare the correct login credentials
        String correctUsername = "student123";
        String correctPassword = "java2026";
        boolean accountLocked = false;


        String username = "student123";
        String password = "wrongpass";

        System.out.println("===== Nested Login Validator =====");

        // Stage 1: Check the username
        if (username.equals(correctUsername)) {
            System.out.println("Username: Correct");

            // Stage 2: Check the password only if username matches
            if (password.equals(correctPassword)) {
                System.out.println("Password: Correct");

                // Stage 3: Check account status only if both credentials match
                if (!accountLocked) {
                    System.out.println("Login Successful!");
                } else {
                    System.out.println("Login Failed: Account is locked.");
                }

            } else {
                System.out.println("Login Failed: Incorrect password.");
            }

        } else {
            System.out.println("Login Failed: Incorrect username.");
        }
    }
}
