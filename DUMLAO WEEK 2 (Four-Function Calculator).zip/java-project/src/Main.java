import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // Read two integers from the user
        System.out.print("Enter first number: ");
        int num1 = input.nextInt();

        System.out.print("Enter second number: ");
        int num2 = input.nextInt();

        // Display the arithmetic results
        System.out.println("\n===== Calculator Results =====");

        System.out.println("Addition (+): " + (num1 + num2));
        System.out.println("Subtraction (-): " + (num1 - num2));
        System.out.println("Multiplication (*): " + (num1 * num2));

        // Integer division truncates the fractional part.
        // With negative operands, division truncates toward zero,
        // and the remainder (%) takes the sign of the dividend (num1).
        if (num2 != 0) {
            System.out.println("Division (/): " + (num1 / num2));
            System.out.println("Modulus (%): " + (num1 % num2));
        } else {
            System.out.println("Division (/): Cannot divide by zero");
            System.out.println("Modulus (%): Cannot divide by zero");
        }

        input.close();
    }
}
