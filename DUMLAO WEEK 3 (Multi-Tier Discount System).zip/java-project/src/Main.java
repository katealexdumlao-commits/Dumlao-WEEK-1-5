public class Main {
    public static void main(String[] args) {

        // Declare the purchase amount
        double purchaseAmount = 6000.00;

        double discountRate;
        String discountTier;

        // Assign a discount based on the purchase amount
        if (purchaseAmount < 1000) {
            discountRate = 0.00;
            discountTier = "No Discount (0%)";
        } else if (purchaseAmount < 3000) {
            discountRate = 0.05;
            discountTier = "Bronze Tier (5%)";
        } else if (purchaseAmount < 5000) {
            discountRate = 0.10;
            discountTier = "Silver Tier (10%)";
        } else {
            discountRate = 0.15;
            discountTier = "Gold Tier (15%)";
        }

        // Calculate the discount and final price
        double discountAmount = purchaseAmount * discountRate;
        double finalPrice = purchaseAmount - discountAmount;

        // Print the shopping summary
        System.out.println("===== Multi-Tier Discount System =====");
        System.out.printf("Purchase Amount: %.2f%n", purchaseAmount);
        System.out.println("Discount Tier: " + discountTier);
        System.out.printf("Discount Amount: %.2f%n", discountAmount);
        System.out.printf("Final Discounted Price: %.2f%n", finalPrice);
    }
}
