public class Main {
    public static void main(String[] args) {

        int size = 5;

        for (int row = 1; row <= size; row++) {

            if (row == 3) {
                continue;
            }

            for (int col = 1; col <= row; col++) {

                if (col == 4) {
                    break;
                }

                System.out.print("* ");
            }

            System.out.println();
        }
    }
}
