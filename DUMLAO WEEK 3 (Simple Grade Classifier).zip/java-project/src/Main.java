public class Main {
    public static void main(String[] args) {

        // Declare an integer variable for the test score
        int score = 85;

        // Check if the score is passing or failing
        if (score >= 60) {
            System.out.println("Score: " + score);
            System.out.println("PASSED");
        } else {
            System.out.println("Score: " + score);
            System.out.println("FAILED");
        }
    }
}
